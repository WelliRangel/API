const bancodedados = require('../bancodedados')
let { contas } = bancodedados
const listarContas = (req, res) => {
    return res.status(200).json(contas);
}

const cadastarNovoUsuario = (req, res) => {
    let numeroDaConta = contas.length
    const { nome, cpf, data_nascimento, telefone, email, senha } = req.body;

    const usuario = {
        "numero": `${++numeroDaConta}`,
        "saldo": 0,
        "usuario": {
            nome,
            cpf,
            data_nascimento,
            telefone,
            email,
            senha
        }
    }
    contas.push(usuario)
    return res.status(204).json()
}

module.exports = {
    listarContas,
    cadastarNovoUsuario
}
