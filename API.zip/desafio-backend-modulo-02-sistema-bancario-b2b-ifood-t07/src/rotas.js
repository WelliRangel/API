const express = require("express");
const rotas = express();

const { validarSenhaGeralBanco, validarNovoCadastro } = require('./intermediarios');
const { listarContas, cadastarNovoUsuario } = require('./controladores/contas');


// GET /contas?senha_banco=Cubos123Bank
rotas.get('/contas', validarSenhaGeralBanco, listarContas)
// POST /contas
rotas.post('/contas', validarNovoCadastro, cadastarNovoUsuario)

// PUT /contas/:numeroConta/usuario
rotas.put('/contas')

// DELETE /contas/:numeroConta 
rotas.delete('/contas')
// POST /transacoes/depositar
rotas.post('/transacoes')
// POST /transacoes/sacar
rotas.post('/transacoes')
// POST /transacoes/transferir
rotas.post('/transacoes')
// GET /contas/saldo?numero_conta=123&senha=123
rotas.get('/contas')
// GET /contas/extrato?numero_conta=123&senha=123
rotas.get('/contas')


module.exports = rotas