const bancodedados = require('./bancodedados')
const { senha } = bancodedados.banco
let { contas } = bancodedados

const validarSenhaGeralBanco = (req, res, next) => {
    const { senha_banco } = req.query;
    if (!senha_banco) {

        return res.status(400).json({ "mensagem": 'Senha não informada' });
    } else if (senha_banco !== senha) {

        return res.status(401).json({ "mensagem": "A senha do banco informada é inválida!" });
    }
    next();
}

const validarNovoCadastro = (req, res, next) => {
    const { nome, cpf, data_nascimento, telefone, email, senha } = req.body;
    const camposObrigatorios = ["nome", "cpf", "data_nascimento", "telefone", "email", "senha"];


    for (const campo of camposObrigatorios) {
        if (!req.body[campo]) {
            return res.status(400).json({ mensagem: `É obrigatorio preencher o campo ${campo}` });
        }
    }
    for (const conta of contas) {
        if (conta.usuario.cpf === cpf || conta.usuario.email === email) {
            return res.status(400).json({ "mensagem": "Já existe uma conta com o cpf ou e-mail informado!" })
        }
    }
    next()








}
module.exports = {
    validarSenhaGeralBanco,
    validarNovoCadastro

}